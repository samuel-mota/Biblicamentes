	<footer id="footer">
		<div class="scroll-top scroll-top-hidden"></div>
		<section id="footer-top" class="container" >
			<article class="books-nav">
				<div class="old-books">
					<h4>Velho Testamento</h4>
					<div class="old-book-links">
						<a class="book-btn" href="#">Gênesis</a>
						<a class="book-btn" href="#">Êxodo</a>
						<a class="book-btn" href="#">Levítico</a>
						<a class="book-btn" href="#">Números</a>
						<a class="book-btn" href="#">Deuteronômio</a>
						<a class="book-btn" href="#">Josué</a>
						<a class="book-btn" href="#">Juízes</a>
						<a class="book-btn" href="#">Rute</a>
						<a class="book-btn" href="#">1Samuel</a>
						<a class="book-btn" href="#">2Samuel</a>
						<a class="book-btn" href="#">1Reis</a>
						<a class="book-btn" href="#">2Reis</a>
						<a class="book-btn" href="#">1Crônicas</a>
						<a class="book-btn" href="#">2Crônicas</a>
						<a class="book-btn" href="#">Esdras</a>
						<a class="book-btn" href="#">Neemias</a>
						<a class="book-btn" href="#">Ester</a>
						<a class="book-btn" href="#">Jó</a>
						<a class="book-btn" href="#">Salmos</a>
						<a class="book-btn" href="#">Provérbios</a>
						<a class="book-btn" href="#">Eclesiastes</a>
						<a class="book-btn" href="#">Cântico</a>
						<a class="book-btn" href="#">Isaías</a>
						<a class="book-btn" href="#">Jeremias</a>
						<a class="book-btn" href="#">Lamentações</a>
						<a class="book-btn" href="#">Ezequiel</a>
						<a class="book-btn" href="#">Daniel</a>
						<a class="book-btn" href="#">Oseias</a>
						<a class="book-btn" href="#">Joel</a>
						<a class="book-btn" href="#">Amós</a>
						<a class="book-btn" href="#">Obadias</a>
						<a class="book-btn" href="#">Jonas</a>
						<a class="book-btn" href="#">Miqueias</a>
						<a class="book-btn" href="#">Naum</a>
						<a class="book-btn" href="#">Habacuque</a>
						<a class="book-btn" href="#">Sofonias</a>
						<a class="book-btn" href="#">Ageu</a>
						<a class="book-btn" href="#">Zacarias</a>
						<a class="book-btn" href="#">Malaquias</a>
					</div>
				</div>
				<div class="new-books">
					<h4>Novo Testamento</h4>
					<div class="new-book-links">
						<a class="book-btn" href="#">Mateus</a>
						<a class="book-btn" href="#">Marcos</a>
						<a class="book-btn" href="#">Lucas</a>
						<a class="book-btn" href="#">João</a>
						<a class="book-btn" href="#">Atos</a>
						<a class="book-btn" href="#">Romanos</a>
						<a class="book-btn" href="#">1Coríntios</a>
						<a class="book-btn" href="#">2Coríntios</a>
						<a class="book-btn" href="#">Gálatas</a>
						<a class="book-btn" href="#">Efésios</a>
						<a class="book-btn" href="#">Filipenses</a>
						<a class="book-btn" href="#">Colossenses</a>
						<a class="book-btn" href="#">1Tessalonicenses</a>
						<a class="book-btn" href="#">2Tessalonicenses</a>
						<a class="book-btn" href="#">1Timóteo</a>
						<a class="book-btn" href="#">2Timóteo</a>
						<a class="book-btn" href="#">Tito</a>
						<a class="book-btn" href="#">Filemon</a>
						<a class="book-btn" href="#">Hebreus</a>
						<a class="book-btn" href="#">Tiago</a>
						<a class="book-btn" href="#">1Pedro</a>
						<a class="book-btn" href="#">2Pedro</a>
						<a class="book-btn" href="#">1João</a>
						<a class="book-btn" href="#">2João</a>
						<a class="book-btn" href="#">3João</a>
						<a class="book-btn" href="#">Judas</a>
						<a class="book-btn" href="#">Apocalipse</a>
					</div>
				</div>
			</article>

			<nav class="navbar-footer">
				<ul class="nav-items">
					<a href="estudo.php">
						<li>
							<i class="fas fa-book fa-2x fa-pull-left fa-border"></i><strong>Estudo Bíblico</strong><br>
							<em>Leitura da Bíblia com Referências Cruzadas, Dicionário e links informativos. 
							Bíblia Utilizada: Bíblia King James Atualizada (KJA)</em>
						</li>
					</a>
					<a href="#">
						<li>
							<i class="fas fa-eye fa-2x fa-pull-left fa-border"></i> <strong>WikiBiblia</strong><br>
							<em>Informações extras para complementar sua leitura bíblica.</em>
						</li>
					</a>
					<a href="contribua.php">
						<li><i class="fas fa-donate fa-2x fa-pull-left fa-border"></i> <strong>Contribua</strong><br>
							<em>Ajude-nos a manter o website!</em>
						</li>
					</a>
					<a href="fale-conosco.php">
						<li>
							<i class="far fa-envelope fa-2x fa-pull-left fa-border"></i> <strong>Fale Conosco</strong><br>
							<em>Envie-nos uma mensagem!</em>
						</li>
					</a>
					<a href="fale-conosco.php">
						<li>
							<i class="fas fa-bug fa-2x fa-pull-left fa-border"></i> <strong>Bug/Erros</strong><br>
							<em>Se encontrar algum erro/bug por favor nos avise!</em>
						</li>
					</a>
				</ul>
			</nav>
		</section>

		<div id="footer-bottom">
			<div class="nav-social">
				<a href="https://www.facebook.com/biblicamentes" rel="noopener" target="_blank" class="link-facebook link-social">
					<i class="fab fa-facebook-f"></i>
				</a>
				<a href="https://twitter.com/biblicamentes" rel="noopener" target="_blank"class="link-twitter link-social">
					<i class="fab fa-twitter"></i>
				</a>
				<a href="https://www.instagram.com/biblicamentes" rel="noopener" target="_blank"class="link-instagram link-social">
					<i class="fab fa-instagram"></i>
				</a>
			</div>
			<div class="copyright">
				Copyright © 2019 <strong>Biblicamentes</strong>. Todos os direitos reservados.
			</div>
		</div>
	</footer>

	<!-- BEGIN JAVASCRIPT -->
	<script src="js/jquery.js"></script>
	<!--<script src="bootstrap/js/bootstrap.min.js"></script>-->
	<script src="js/scripts.js"></script>
	<!-- END JAVASCRIPT -->

</body>
</html>