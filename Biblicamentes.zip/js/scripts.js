//******************
// main mobile menu toggle
//******************
const navbarMobileMenu = () => {
	const buttonX = document.querySelector('.button-x');
	const buttonBars = document.querySelector('.button-bars');
	const activeToggle = document.querySelector('.nav-menu');

	buttonX.classList.toggle('button-toggle');
	buttonBars.classList.toggle('button-toggle');
	
	if (activeToggle.classList.contains('nav-menu-hidden')) {
		activeToggle.style.display = "block";
		setTimeout(function() {
			activeToggle.classList.toggle('nav-menu-hidden');
		}, 100);
	} else {
		activeToggle.classList.toggle('nav-menu-hidden');
		setTimeout(function() {
			activeToggle.style.display = "none";
		}, 300);
	}
};

document.querySelector('.navbar-toggler').addEventListener('click', navbarMobileMenu); // call after assign the variable


//******************
// scroll to top
//******************
const detectScroll = (pxDown, elementToSelected, classToggle, removeFirst) => {
	const elementSelected = document.querySelector(elementToSelected);
	const docScrolled = document.body.scrollTop || document.documentElement.scrollTop; // body FOR SAFARI, documentElement FOR CHROME, FIREFOX, IE and OPERA
	const stopPoint = document.getElementById("footer").offsetTop;

	//change classes
  if (docScrolled > pxDown) { // in px
    if (removeFirst) {
    	elementSelected.classList.remove(classToggle);
    } else {
    	elementSelected.classList.add(classToggle);
    }
  } else {
    if (removeFirst) {
    	elementSelected.classList.add(classToggle);
    } else {
    	elementSelected.classList.remove(classToggle);
    }
  }

  //stop point
  if (docScrolled >= (stopPoint)) {

  }
}

// scroll to the top of the document when click the button
const toTop = () => {
	const docScrolled = document.body.scrollTop || document.documentElement.scrollTop; // body FOR SAFARI, documentElement FOR CHROME, FIREFOX, IE and OPERA

	if (docScrolled != 0) {
		window.requestAnimationFrame(toTop);
		window.scrollTo(0, docScrolled - docScrolled / 10);
		// console.log(docScrolled - docScrolled / 8);
	}
}

document.querySelector('.scroll-top').addEventListener('click', toTop); // call after assign the variable


// show the button when scroll down
window.onscroll = () => { 
	detectScroll(200, ".scroll-top", "scroll-top-hidden", true);
	detectScroll(39, "#header", "header-changed", false);

//	detectScroll(50, ".entry-title", "is-sticky", false);
//	detectScroll(50, ".entry-title-placeholder", "is-active", false);
} // pxDown, elementToSelected, classToggle, removeFirst

