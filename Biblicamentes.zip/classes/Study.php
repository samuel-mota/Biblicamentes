<?php

class Study {
	public $id;
	public $cod_livro;
	public $livro;
	public $cap;
	public $ver;
	public $texto;
	
// 	public function __construct($cod_livro = '01gnx001%') {
// 		$this->cod_livro = $cod_livro;
// 			//ChromePhp::log($this->cod_livro);
// 		$this->getVerses();
// 	}
	
// JÁ ESTA FUNCIONANDO
// 	public function getVerses() {
// 		$query = "SELECT ver, texto FROM biblicamentes.bibliakja WHERE cod_livro LIKE '01gnx030%'";
// 		$connection = Connect::getConnection();
		
// 		$result = $connection->query($query);
// 		$verses = $result->fetchAll();	
// 		return $verses;
// 	}

	public static function getVerses($cod_livro) {
		$query = "SELECT ver, texto FROM biblicamentes.bibliakja WHERE cod_livro LIKE :cod_livro";
		$connection = Connect::getConnection();
		$statement = $connection->prepare($query);

		$statement->bindValue(':cod_livro', $cod_livro);
		$statement->execute();
		$verses = $statement->fetchAll();	
		return $verses;
	}
	
	public static function getBookAndChapter($cod_livro) {
		$query = "SELECT livro, cap FROM biblicamentes.bibliakja WHERE cod_livro LIKE :cod_livro";
		$connection = Connect::getConnection();
		
		//$result = $connection->query($query);
		$statement = $connection->prepare($query);
		$statement->bindValue(':cod_livro', $cod_livro);
		$statement->execute();
		$chapter = $statement->fetch();
		return $chapter;
		
		// o mesmo que: 
		// return $chapter = Connect::getConnection()->query("SELECT cap FROM biblicamentes.bibliakja WHERE cod_livro LIKE '01gnx030%'")->fetch();
	}
	
	public static function getBook($cod_livro) {
		$query = "SELECT livro FROM biblicamentes.bibliakja WHERE cod_livro LIKE :cod_livro";
		$connection = Connect::getConnection();
		$statement = $connection->prepare($query);

		$statement->bindValue(':cod_livro', $cod_livro);
		$statement->execute();
		$book = $statement->fetch();	
		return $book;
	}
}