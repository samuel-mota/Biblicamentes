<!DOCTYPE html>
<html lang="pt">
<head>
	<meta charset="utf-8">
	<title>Biblicamentes - Estudo</title>
	
	<!--device-width = abrir com o tamanho da tela do aparelho; initial-scale=1 = escala padrão 1 do dispositivo-->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="BiblicaMentes, ler, meditar, estudar a palavra de Deus.">
	<meta name="keywords" CONTENT="Biblicamentes, Bíblia, Jesus, Deus">
	<meta name="author" content="Copyright © 2018 - biblicamentes.com.br">
	<meta name="robots" CONTENT="index, follow, all">
	
	<!-- BEGIN CSS TEMPLATE -->
	<link rel="icon" href="favicon.png">
	<link rel="stylesheet" href="css/normalize.css">
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/books.css">
	<!-- END CSS TEMPLATE -->
</head>


<?php 
	include 'ChromePhp.php'; // para mostrar no console
	
	require_once 'header.php';
	require_once 'load-classes.php';
	


	//https://www.w3schools.com/pHP/php_exception.asp
	//https://www.php.net/manual/en/language.exceptions.php
	//https://www.php.net/manual/en/internals2.opcodes.catch.php
 	try {
 		if (isset($_GET['cod_livro']) && !empty($_GET['cod_livro'])) {
			$cod_livro = $_GET['cod_livro'];
				//ChromePhp::log('get:'.$cod_livro);
			//$chapter = new Study($cap);
			
			//$verses2 = $verses->getVerses();
		} else {		
			$cod_livro = '01gnx001%';
	//		$verses = Study::getVerses();
	//		$chapter = Study::getChapter();
		}
		$verses = Study::getVerses($cod_livro);
		$chapter = Study::getBookAndChapter($cod_livro);
		//$book = Study::getBook($cod_livro);
		
 	} catch (Exception $e) {

 		//echo ('MENSAGEM: ' . $e->getMessage());
 		ChromePhp::log('MENSAGEM: ' . $e->getMessage());
 	}
	
	
?>


	<section id="content" class="container">
		<!-- CONTEUDO DO LIVRO  -->
		<main class="main-content">
			<!-- <div class="entry-title-placeholder"></div> -->
			<!-- <hgroup class="meta-wrapper"> -->
			<div class="entry-title-wrapper is-sticky">
				<h1 class="entry-title"><?= $chapter['livro'] . ' ' . $chapter['cap'] ?></h1>
			</div>
				<!-- <p class="breadcrumb-meta">
					<small>
						<a href="#">Estudo Bíblico</a> > <a href="#">Gênesis</a>
					</small>
				</p> -->
			<!-- </hgroup> -->
			<div class="entry-content">
				<p class="breadcrumb-meta">
					<small>
						<a href="#">|||Estudo Bíblico|||</a> > <a href="#">|||Nome do Livro|||</a>
					</small>
				</p>
				
				
				<?php if (count($verses) >= 0) : ?>
				
				
				<table class="tabela-versiculos">
					<thead>
						<tr>
							<th>Versículos</th>							
							<th>Texto</th>
						</tr>
					</thead>
					<tbody>
						
						<?php foreach ($verses as $verse) : ?>
						
						<tr>
							<td><?= $verse['ver'] ?></td>
							<td><?= $verse['texto'] ?></td>
						</tr>
						
						<?php endforeach ?>
						
					</tbody>
				</table>

				
				<?php else : ?>
				
				<p>Nenhum versículo encontrado</p>
				
				<?php endif ?>
				
				
			</div>
		</main>

		<aside id="nav-bible">
			<div class="nav-bible-wrapper">
				<div class="nav-chapters">
				|||FAZER CHAMADA DOS CAPITULOS DO LIVRO ESPECIFICO|||
					<a class="book-btn" href="estudo.php?cod_livro='01gnx001%'">Cap 1 Gênesis</a>
					<a class="book-btn" href="#">1</a>
					<a class="book-btn" href="#">1</a>
					<a class="book-btn" href="#">1</a>
					<a class="book-btn" href="#">1</a>
					<a class="book-btn" href="#">1</a>
					<a class="book-btn" href="#">1</a>
					<a class="book-btn" href="#">1</a>
					<a class="book-btn" href="#">1</a>
					<a class="book-btn" href="#">1</a>
					<a class="book-btn" href="#">1</a>
					<a class="book-btn" href="#">1</a>
					<a class="book-btn" href="#">1</a>
					<a class="book-btn" href="#">1</a>
					<a class="book-btn" href="#">1</a>
					<a class="book-btn" href="#">1</a>
					<a class="book-btn" href="#">1</a>
					<a class="book-btn" href="#">1</a>
					<a class="book-btn" href="#">1</a>
				</div>
				<div class="nav-books">
					|||CHAMADA DO LIVRO ANTERIOR E DO PROXIMO|||
				</div>
			</div>
		</aside>
	</section> 

	<div class="divider-bar"></div>


<?php require_once 'footer.php' ?>